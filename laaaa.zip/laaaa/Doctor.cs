﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace labassignment1
{
    public partial class Doctor : Form
    {
        String conStr = "server=DESKTOP-UPQHA4F\\SQLEXPRESS;database=csharp;uid=lab;pwd=123;";
        public Doctor()
        {
            InitializeComponent();
        }

        private void Doctor_Load(object sender, EventArgs e)
        {

        }

        private void Button6_Click(object sender, EventArgs e)
        {
                SqlConnection con = new SqlConnection(conStr);
                con.Open();
                string add = "exec addpatInfo '" + int.Parse(txtpid.Text) + "', '" + int.Parse(txtdiid.Text) + "','" + txtp.Text + " ','" + txtm.Text + " ','" + txtd.Text + " ','" + txtsii.Text + " '";

                SqlCommand cmd = new SqlCommand(add, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfull");

                show();

            
        }
        void show()
        {
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand c = new SqlCommand("viewpatinfo  '" + int.Parse(txtpid.Text) + "'", con);
            SqlDataAdapter sd = new SqlDataAdapter(c);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand c = new SqlCommand("searchpatinfooo '" + txtu4.Text + "' ", con);
                SqlDataAdapter sd = new SqlDataAdapter(c);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridView2.DataSource = dt;
                txtu4.Text = "";
            
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand c = new SqlCommand("viewallpat'" + int.Parse(txtd6.Text) + "' ", con);
                SqlDataAdapter sd = new SqlDataAdapter(c);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridView2.DataSource = dt;
                txtd6.Text = "";

            
        }

        private void Button10_Click(object sender, EventArgs e)
        {

            
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand c = new SqlCommand("docdetail'" + int.Parse(txtd6.Text) + "' ", con);
                SqlDataAdapter sd = new SqlDataAdapter(c);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridView2.DataSource = dt;
                txtd6.Text = "";


        }

        private void Button7_Click(object sender, EventArgs e)
        {
            txtpid.Text = "";
            txtfn.Text = "";
            txtfn.Text = "";
            txtdiid.Text = "";
            txtp.Text = "";
            txtm.Text = "";
            txtd.Text = "";
            txtsii.Text = "";

        }

        private void Button11_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conStr);
            con.Open();
            string add = "exec addpatInfo '" + int.Parse(txtpid.Text) + "', '" + int.Parse(txtdiid.Text) + "','" + txtp.Text + " ','" + txtm.Text + " ','" + txtd.Text + " ','" + txtsii.Text + " '";

            SqlCommand cmd = new SqlCommand(add, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfull");

            show();
        }
    }
}
