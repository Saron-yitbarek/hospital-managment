﻿namespace labassignment1
{
    partial class Doctor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtpid = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.txtsii = new System.Windows.Forms.TextBox();
            this.txtfn = new System.Windows.Forms.TextBox();
            this.txtfan = new System.Windows.Forms.TextBox();
            this.txtdiid = new System.Windows.Forms.TextBox();
            this.txtp = new System.Windows.Forms.TextBox();
            this.txtm = new System.Windows.Forms.TextBox();
            this.txtd = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtd6 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.txtu4 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button11);
            this.groupBox3.Controls.Add(this.txtpid);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.txtsii);
            this.groupBox3.Controls.Add(this.txtfn);
            this.groupBox3.Controls.Add(this.txtfan);
            this.groupBox3.Controls.Add(this.txtdiid);
            this.groupBox3.Controls.Add(this.txtp);
            this.groupBox3.Controls.Add(this.txtm);
            this.groupBox3.Controls.Add(this.txtd);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(503, 384);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Patient Report Form";
            // 
            // txtpid
            // 
            this.txtpid.Location = new System.Drawing.Point(66, 34);
            this.txtpid.Name = "txtpid";
            this.txtpid.Size = new System.Drawing.Size(58, 20);
            this.txtpid.TabIndex = 17;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 37);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "PatientID";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(339, 331);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(89, 34);
            this.button7.TabIndex = 15;
            this.button7.Text = "Clear";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(123, 331);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(88, 34);
            this.button6.TabIndex = 14;
            this.button6.Text = "Save";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // txtsii
            // 
            this.txtsii.Location = new System.Drawing.Point(94, 274);
            this.txtsii.Multiline = true;
            this.txtsii.Name = "txtsii";
            this.txtsii.Size = new System.Drawing.Size(334, 51);
            this.txtsii.TabIndex = 13;
            // 
            // txtfn
            // 
            this.txtfn.Location = new System.Drawing.Point(66, 59);
            this.txtfn.Name = "txtfn";
            this.txtfn.Size = new System.Drawing.Size(124, 20);
            this.txtfn.TabIndex = 12;
            // 
            // txtfan
            // 
            this.txtfan.Location = new System.Drawing.Point(266, 59);
            this.txtfan.Name = "txtfan";
            this.txtfan.Size = new System.Drawing.Size(111, 20);
            this.txtfan.TabIndex = 11;
            // 
            // txtdiid
            // 
            this.txtdiid.Location = new System.Drawing.Point(439, 59);
            this.txtdiid.Name = "txtdiid";
            this.txtdiid.Size = new System.Drawing.Size(58, 20);
            this.txtdiid.TabIndex = 10;
            // 
            // txtp
            // 
            this.txtp.Location = new System.Drawing.Point(94, 96);
            this.txtp.Multiline = true;
            this.txtp.Name = "txtp";
            this.txtp.Size = new System.Drawing.Size(334, 56);
            this.txtp.TabIndex = 9;
            // 
            // txtm
            // 
            this.txtm.Location = new System.Drawing.Point(94, 158);
            this.txtm.Multiline = true;
            this.txtm.Name = "txtm";
            this.txtm.Size = new System.Drawing.Size(334, 51);
            this.txtm.TabIndex = 8;
            // 
            // txtd
            // 
            this.txtd.Location = new System.Drawing.Point(94, 215);
            this.txtd.Multiline = true;
            this.txtd.Name = "txtd";
            this.txtd.Size = new System.Drawing.Size(334, 50);
            this.txtd.TabIndex = 7;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(-2, 277);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 13);
            this.label17.TabIndex = 6;
            this.label17.Text = "Special Instruction";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(35, 218);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(32, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Dose";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(35, 158);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Medicaton";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(35, 99);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 13);
            this.label14.TabIndex = 3;
            this.label14.Text = "Problem";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(192, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "Father Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 62);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "First Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(383, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "DoctorID";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtd6);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.txtu4);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Location = new System.Drawing.Point(611, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 332);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Searching";
            // 
            // txtd6
            // 
            this.txtd6.Location = new System.Drawing.Point(71, 166);
            this.txtd6.Name = "txtd6";
            this.txtd6.Size = new System.Drawing.Size(100, 20);
            this.txtd6.TabIndex = 21;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(5, 169);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 20;
            this.label19.Text = "Doctor ID";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(46, 206);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(125, 34);
            this.button9.TabIndex = 22;
            this.button9.Text = " All Patient Info";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(46, 256);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(125, 34);
            this.button10.TabIndex = 23;
            this.button10.Text = "Personal Info";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Button10_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(57, 96);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(89, 34);
            this.button8.TabIndex = 16;
            this.button8.Text = "Search Patient Info";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // txtu4
            // 
            this.txtu4.Location = new System.Drawing.Point(82, 47);
            this.txtu4.Name = "txtu4";
            this.txtu4.Size = new System.Drawing.Size(100, 20);
            this.txtu4.TabIndex = 17;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(16, 50);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 13);
            this.label18.TabIndex = 16;
            this.label18.Text = "User Name";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(15, 404);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(813, 195);
            this.dataGridView2.TabIndex = 20;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(240, 331);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 34);
            this.button11.TabIndex = 21;
            this.button11.Text = "Update";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Button11_Click);
            // 
            // Doctor
            // 
            this.ClientSize = new System.Drawing.Size(840, 611);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Name = "Doctor";
            this.Text = "Doctor";
            this.Load += new System.EventHandler(this.Doctor_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtSI;
        private System.Windows.Forms.TextBox txtdose;
        private System.Windows.Forms.TextBox txtmedication;
        private System.Windows.Forms.TextBox txtProblem;
        private System.Windows.Forms.TextBox txtFNN;
        private System.Windows.Forms.TextBox txtMNN;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtu2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtdID;
        private System.Windows.Forms.TextBox txtPIDD;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtd4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox txtsii;
        private System.Windows.Forms.TextBox txtfn;
        private System.Windows.Forms.TextBox txtfan;
        private System.Windows.Forms.TextBox txtdiid;
        private System.Windows.Forms.TextBox txtp;
        private System.Windows.Forms.TextBox txtm;
        private System.Windows.Forms.TextBox txtd;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtd6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox txtu4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox txtpid;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button11;
    }
}