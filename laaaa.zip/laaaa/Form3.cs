﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace labassignment1
{
    public partial class Form3 : Form
    {
        String conStr = "server=DESKTOP-UPQHA4F\\SQLEXPRESS;database=csharp;uid=lab;pwd=123;";
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (rbtnP2.Checked)
            {
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand c = new SqlCommand("seaarchUser '" + txtu2.Text + "' ", con);
                SqlDataAdapter sd = new SqlDataAdapter(c);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else if (rbtnD2.Checked)
            {
                SqlConnection con = new SqlConnection(conStr);
                SqlCommand c = new SqlCommand("seaarchdoc '" + txtu2.Text + "'", con);
                SqlDataAdapter sd = new SqlDataAdapter(c);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(conStr))

            {
                if (rbtnpP.Checked) {
                    if (txtPass.Text != txtCpass.Text)
                    {
                        MessageBox.Show("Please enter your password aganin");
                        txtCpass.Text = " ";
                        txtPass.Text = " ";
                    }
                    else
                    {
                        string g = "NULL";
                        if (rbtnD.Checked)
                            g = "Doctor";
                        else if (rbtnpP.Checked)
                            g = "Patient";


                        con.Open();
                        string add = "exec addPatient '" + txtFN.Text + "', '" + txtMN.Text + "','" + tXTLN.Text + " ','" + int.Parse(txtAge.Text) + " ','" + txtSex.Text + " ','" + txtemail.Text + " ','" + txtUser.Text + " ','" + txtPass.Text + " ','" + g + " ','" + int.Parse(txtid.Text) + " '";

                        SqlCommand cmd = new SqlCommand(add, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("successfull");
                        show();
                    }
                    
                }
                else if (rbtnD.Checked){
                        if (txtPass.Text != txtCpass.Text)
                        {
                            MessageBox.Show("Please enter your password aganin");
                            txtCpass.Text = " ";
                            txtPass.Text = " ";
                        }
                        else
                        {
                            string g = "NULL";
                            if (rbtnD.Checked)
                                g = "Doctor";
                            else if (rbtnpP.Checked)
                                g = "Patient";


                            con.Open();
                            string add = "exec addDoctor '" + txtFN.Text + "', '" + txtMN.Text + "','" + tXTLN.Text + " ','" + int.Parse(txtAge.Text) + " ','" + txtSex.Text + " ','" + txtemail.Text + " ','" + txtUser.Text + " ','" + txtPass.Text + " ','" + g + " ','" + int.Parse(txtid.Text) + " '";

                            SqlCommand cmd = new SqlCommand(add, con);
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("successfull");
                        showD();
                    }
                    }
            }
        }

        void show()
        {
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand c = new SqlCommand("viewPatient", con);
            SqlDataAdapter sd = new SqlDataAdapter(c);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void Button4_Click(object sender, EventArgs e)
        {
            txtFN.Text = "";
            txtMN.Text = "";
            tXTLN.Text = "";
            txtAge.Text = "";
            txtSex.Text = "";
            txtemail.Text = "";
            txtUser.Text = "";
            txtPass.Text = "";
            txtCpass.Text = "";
            txtid.Text = "";


        }

        private void Button1_Click(object sender, EventArgs e)
        {
            show();
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            showD();

        }
        void showD()
        {
            SqlConnection con = new SqlConnection(conStr);
            SqlCommand c = new SqlCommand("viewDoctor", con);
            SqlDataAdapter sd = new SqlDataAdapter(c);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void Button6_Click(object sender, EventArgs e)
        {
            if (rbtnd3.Checked)
            {
                SqlConnection con = new SqlConnection(conStr);
                con.Open();
                SqlCommand c = new SqlCommand("deleteDoctor '" + txtu3.Text + "'", con);
                c.ExecuteNonQuery();
                MessageBox.Show(" Deleted successfull");
                showD();
            }
            else if (rbtnp3.Checked)
            {
                SqlConnection con = new SqlConnection(conStr);
                con.Open();
                SqlCommand c = new SqlCommand("deletePatient '" + txtu3.Text + "'", con);
                c.ExecuteNonQuery();
                MessageBox.Show(" Deleted successfull");
                show();
            }

        }
    }
}
