﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace labassignment1
{
    public partial class Form1 : Form
    {
        String conStr = "server=DESKTOP-UPQHA4F\\SQLEXPRESS;database=csharp;uid=lab;pwd=123;";
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
           
    }

        private void Button1_Click_1(object sender, EventArgs e)
        {

            if (usertxt.Text == "" || passtxt.Text == "")
            {
                MessageBox.Show("User name or password  fields are empty ");
            }
            else
            {
                if (ARbtn.Checked || Prbtn.Checked || Drbtn.Checked)
                {
                    if (ARbtn.Checked)
                    {
                        SqlConnection con = new SqlConnection(conStr);
                        con.Open();
                        string login = " exec logadmin'" + usertxt.Text + "' ,'" + passtxt.Text + "'";
                        SqlCommand cmd = new SqlCommand(login, con);
                        SqlDataReader r = cmd.ExecuteReader();

                        if (r.Read() == true)
                        {
                            new Form3().Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect user name or password ,Please try again");
                            usertxt.Text = "";
                            passtxt.Text = "";

                        }
                    }
                    else if (Drbtn.Checked)
                    {
                        SqlConnection con = new SqlConnection(conStr);
                        con.Open();
                        string login = " exec logdoc'" + usertxt.Text + "' ,'" + passtxt.Text + "'";
                        SqlCommand cmd = new SqlCommand(login, con);
                        SqlDataReader r = cmd.ExecuteReader();

                        if (r.Read() == true)
                        {
                            new Doctor().Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect user name or password ,Please try again");
                            usertxt.Text = "";
                            passtxt.Text = "";

                        }
                    }
                    else if (Prbtn.Checked)
                    {
                        SqlConnection con = new SqlConnection(conStr);
                        con.Open();
                        string login = " exec logpat'" + usertxt.Text + "' ,'" + passtxt.Text + "'";
                        SqlCommand cmd = new SqlCommand(login, con);
                        SqlDataReader r = cmd.ExecuteReader();

                        if (r.Read() == true)
                        {
                            new Patient().Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect user name or password ,Please try again");
                            usertxt.Text = "";
                            passtxt.Text = "";

                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please press one of the button");
                }

            }
        }

        private void Usertxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
    
