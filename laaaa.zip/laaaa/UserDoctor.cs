﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labassignment1
{
    class UserDoctor
    {

        public string FName, FAName, Prob, Med, Dose, SpeIns, UserName;
        public int PID, DID, DIDD;

        public UserDoctor() { }
        public UserDoctor(string FName, string FAName, string Prob, string Med, string Dose,
            string SpeIns, string UserName, int PID, int DID, int DIDD)
        {
            this.FName = FName;
            this.FAName = FAName;
            this.Prob = Prob;
            this.Med = Med;
            this.Dose = Dose;
            this.SpeIns = SpeIns;
            this.UserName = UserName;
            this.PID = PID;
            this.DID = DID;
            this.DIDD = DIDD;


        }
    }
}
