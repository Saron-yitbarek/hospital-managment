﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labassignment1
{
    class UsserAdmin
    {
       public  string FName, MidName, LastName, email, user, pass, conpass;
        public char sex;
        public int age, AId;
        public UsserAdmin()
        {

        }
        public UsserAdmin(string FName , string MidName, string LastName ,int age, char sex,string email
            , string user, string pass, string conpass,int AId)
        {
            this.FName = FName;
            this.MidName = MidName;
                 this.LastName = LastName;
            this.age = age;
            this.sex = sex;
            this.email = email;
            this.user = user;
            this.pass = pass;
            this.conpass = conpass;
            this.AId = AId;


        }



    }
}
