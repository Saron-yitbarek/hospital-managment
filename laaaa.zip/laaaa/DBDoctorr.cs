﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;


namespace labassignment1
{
    class Doctorr
    {
        String conStr = "server=DESKTOP-UPQHA4F\\SQLEXPRESS;database=csharp;uid=lab;pwd=123;";

     
        UserDoctor d = new UserDoctor();
        public void addPatInfo(DataGridView daa)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    
                    con.Open();
                    string add = "exec addpatInfo '" + d.PID + "', '" + d.DID + "','" + d.Prob + " ','" + d.Med + " ','" + d.Dose + " ','" + d.SpeIns + " '";

                    SqlCommand cmd = new SqlCommand(add, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfull");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }




        }
        public void show(DataGridView daa)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {

                    SqlCommand c = new SqlCommand("viewpatinfo  '" + d.PID + "'", con);
                    SqlDataAdapter sd = new SqlDataAdapter(c);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    daa.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public void searchpat(DataGridView daa)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    
                    SqlCommand c = new SqlCommand("searchpatinfooo '" + d.UserName + "' ", con);
                    SqlDataAdapter sd = new SqlDataAdapter(c);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    daa.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void viewAllPat(DataGridView daa)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                   
                    SqlCommand c = new SqlCommand("viewallpat'" + d.DIDD + "' ", con);
                    SqlDataAdapter sd = new SqlDataAdapter(c);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    daa.DataSource = dt;
                    //txtd6.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public void docDetail(DataGridView daa)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                   
                    SqlCommand c = new SqlCommand("docdetail'" + d.DIDD + "' ", con);
                    SqlDataAdapter sd = new SqlDataAdapter(c);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    daa.DataSource = dt;
                    // txtd6.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



    }

}
}
