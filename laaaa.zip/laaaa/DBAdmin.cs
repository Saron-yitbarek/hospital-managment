﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;


namespace labassignment1
{
    class DBAdmin
    {
        String conStr = "server=DESKTOP-UPQHA4F\\SQLEXPRESS;database=csharp;uid=lab;pwd=123;";
        UsserAdmin u = new UsserAdmin();


        public void searchUser(DataGridView daa)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {

                    SqlCommand c = new SqlCommand("seaarchUser '" + u.user + "' ", con);
                    SqlDataAdapter sd = new SqlDataAdapter(c);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                   daa.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
            public void searchDoc(DataGridView daa)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {

                    SqlCommand c = new SqlCommand("seaarchdoc '" + u.user + "'", con);
                    SqlDataAdapter sd = new SqlDataAdapter(c);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    daa.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void addpat()
        {

            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {

                    con.Open();
                    string add = "exec addPatient '" + u.FName + "', '" + u.MidName + "','" + u.LastName + " ','" + u.age + " ','" + u.sex + " ','" + u.email + " ','" + u.user + " ','" + u.pass + " ','" + 'F' + " ','" + u.AId + " '";

                    SqlCommand cmd = new SqlCommand(add, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("successfull");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void addDoc()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {


                    string add = "exec addDoctor '" + u.FName + "', '" + u.MidName + "','" + u.LastName + " ','" + u.age + " ','" + u.sex + " ','" + u.email + " ','" + u.user + " ','" + u.pass + " ','" + 'F' + " ','" + u.AId + " '";

                    SqlCommand cmd = new SqlCommand(add, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("successfull");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void show(DataGridView daa)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {

                    SqlCommand c = new SqlCommand("viewPatient", con);
                    SqlDataAdapter sd = new SqlDataAdapter(c);
                    DataTable dt = new DataTable();
                    sd.Fill(dt);
                    daa.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void deletedoctor()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                   
                    con.Open();
                    SqlCommand c = new SqlCommand("deleteDoctor '" + u.user + "'", con);
                    c.ExecuteNonQuery();
                    MessageBox.Show(" Deleted successfull");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void deletepat()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {

                    con.Open();
                    SqlCommand c = new SqlCommand("deletePatient '" + u.user + "'", con);
                    c.ExecuteNonQuery();
                    MessageBox.Show(" Deleted successfull");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
